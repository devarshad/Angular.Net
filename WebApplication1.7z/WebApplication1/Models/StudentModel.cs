﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class StudentModel
    {
        public String Name { get; set; }
        public String Department { get; set; }
        public String Subject { get; set; }
    }
}