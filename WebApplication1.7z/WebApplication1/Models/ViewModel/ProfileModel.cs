﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models.ViewModel
{
    public class ProfileModel
    {
        public String UserName { get; set; }

        public String Password { get; set; }

        public String FullName { get; set; }
    }
}