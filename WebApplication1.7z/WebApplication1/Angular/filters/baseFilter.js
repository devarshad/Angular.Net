﻿angular.module('filters', [])
.filter('baseService', function () {

});