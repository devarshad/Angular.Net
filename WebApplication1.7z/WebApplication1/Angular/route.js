angular.module('routes',['ngRoute'])
.config(['$routeProvider','$locationProvider','$httpProvider',function($routeProvider,$locationProvider,$httpProvider){
	$routeProvider
		.when('/',{templateUrl:'/Angular/templates/home/index.html',
					controller:'homeController'})
		.when('/login',{templateUrl:'/Angular/templates/account/login.html',
					controller:'accountController'})					
		.when('/error',{templateUrl:'/Angular/templates/error/index.html',
					controller:'errorController'})
        .when('/about',{templateUrl:'/Angular/templates/home/about.html',
					controller:'aboutController'})
		.when('/home', { redirectTo: '/' })
		.otherwise({redirectTo:'/error'})
	$locationProvider.html5Mode(true);
}]);