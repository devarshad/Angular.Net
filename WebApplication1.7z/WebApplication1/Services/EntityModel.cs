﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using WebApplication1.Models.ViewModel;

namespace WebApplication1.Services
{
    public sealed class EntityModel
    {
        private static EntityModel _instance = null;
        private static readonly object objLock = new object();

        public List<UserLocationModel> UserLocations { get; set; }

        public static EntityModel Instance
        {
            get
            {
                lock (objLock)
                {
                    if (_instance == null)
                    {
                        _instance = new EntityModel();
                    }
                    return _instance;
                }
            }
        }

        private EntityModel()
        {
            UserLocations = getUserLocations();
        }

        private List<UserLocationModel> getUserLocations()
        {
            return new List<UserLocationModel>
            {
                new UserLocationModel{UserName="Arshad",Position=new GeoLocationRemark{Latitude=1.2,Logitude=-1.3,Remark="Testing one"}},
                new UserLocationModel{UserName="Ayaz",Position=new GeoLocationRemark{Latitude=2.2,Logitude=-1.3,Remark="Testing one"}},
                new UserLocationModel{UserName="Saquib",Position=new GeoLocationRemark{Latitude=3.2,Logitude=-1.3,Remark="Testing one"}},
                new UserLocationModel{UserName="Sachin",Position=new GeoLocationRemark{Latitude=-1.2,Logitude=-1.3,Remark="Testing three"}},
                new UserLocationModel{UserName="Aasif",Position=new GeoLocationRemark{Latitude=5.2,Logitude=-1.3,Remark="Testing five"}},
                new UserLocationModel{UserName="Ravi",Position=new GeoLocationRemark{Latitude=8.2,Logitude=-1.3,Remark="Testing four"}},
                new UserLocationModel{UserName="Furhan",Position=new GeoLocationRemark{Latitude=-10.2,Logitude=-1.3,Remark="Testing four"}},
                new UserLocationModel{UserName="Test",Position=new GeoLocationRemark{Latitude=20.2,Logitude=-1.3,Remark="Testing three"}},
                new UserLocationModel{UserName="Asad",Position=new GeoLocationRemark{Latitude=15.2,Logitude=-1.3,Remark="Testing two"}},
            };
        }
    }
}