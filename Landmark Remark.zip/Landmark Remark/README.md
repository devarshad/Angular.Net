A simple Landmark Remark web Application.

Technology used:
1. .Net stack
	a) ASP.Net MVC Web API
	b) Razor View Engine.
	c) MS Test(Not written)
2. AngularJS
	a) AngularJS base
	b) Angular Routing

3. Methodology
	a) Sigleton Design Pattern
	b) SOLID principles
4. Third party library
	a) Nuget packages(Can be restored on Build)

Functionality:
	a) Any visitor has to register first(SignUp).
	b) Application required to access the user's current location.
	c) User can add any note for his/her current location.
	
Enhacements:
	
This App is using full AngularJS feature and .Net Web API.

This App can be easily extended to any Enterprise application using Landmarking or my favourite places.

This App can consume any source of data(Currently In App object of Users).

This app can be extended to edit/delete the saved note(s).

Limitation:
	a) If user decline for the current location, then app may behave incorrectly(Solely depend on chrome and google map API)
	b) User session is available to the current browser tab.