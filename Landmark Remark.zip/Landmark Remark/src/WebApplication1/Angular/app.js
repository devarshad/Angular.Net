﻿angular
.module('myapp', ['routes', 'services', 'controllers', 'directives', 'filters', 'interceptors']);