﻿angular.module('directives', [])
.directive('baseDirective', function () {
    return { template: '' };
})