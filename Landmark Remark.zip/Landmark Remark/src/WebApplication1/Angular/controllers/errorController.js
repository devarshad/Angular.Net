angular.module('controllers')
.controller('errorController', ['$scope', '$location', function ($scope, $location) {
    
}])