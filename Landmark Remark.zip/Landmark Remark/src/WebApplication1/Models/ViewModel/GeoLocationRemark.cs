﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models.ViewModel
{
    public class GeoLocationRemark
    {
        public Double Latitude { get; set; }

        public Double Logitude { get; set; }

        public String Remark { get; set; }
    }
}